<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'bonecms/laravel-captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Igoshev\\Captcha\\Providers\\CaptchaServiceProvider',
    ),
  ),
  'jivesh/laravel-slack' => 
  array (
    'providers' => 
    array (
      0 => 'Gahlawat\\Slack\\SlackServiceProvider',
    ),
    'aliases' => 
    array (
      'Slack' => 'Gahlawat\\Slack\\Facade\\Slack',
    ),
  ),
);