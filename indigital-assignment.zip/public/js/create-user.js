$(function() 
{

$.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },);

  $("#create-user-form").validate({
   ignore: 'input[type="hidden"]',
   rules: {
    usr_name: {
      required: true,


    },
    usr_email: {
      required: true,
      email:true,
      remote: {
    type: 'post',
    url: 'validate-email',
   
     data: {
        'usr_email': function () { return $('#usr_email').val(); }
    },
   dataType: 'json',
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
    }
    },  
    usr_mobile: {
      required: true,
      regex: /^[1-9]{1}[0-9]{9}$/,
      remote: {
    type: 'post',
    url: 'validate-mobile',
   
     data: {
        'usr_mobile': function () { return $('#usr_mobile').val(); }
    },
   dataType: 'json',
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
    }

    },  
    usr_password: {
      required: true,
    },
    usr_password_repeat: {
      required: true,
        equalTo: '#usr_password'
    },
    usr_company_name: {
      required: true,
    },
    captcha: {
      required: true,
    },

  },

  messages: {

    usr_name: {
      required: "Enter your name.",
    },  
    usr_email: {
      required: "Enter your email.",
      email: "Enter valid email.",
      remote: "Email has already been used. Please use another Email address.",
    },  
    usr_mobile: {
      required: "Enter your mobile No.",
     regex: 'Enter valid Mobile No.',
      remote: "Mobile No. has already been used. Please use another Mobile No.",
    },  
    usr_password: {
      required: "Enter your password.",

    },
    usr_password_repeat: {
      required:  "Enter the same value again.",
    },
    usr_company_name: {
      required:  "Enter company name.",
    },
    
    captcha: {
      required:  "Enter Captcha.",
    },
    
  },
  errorPlacement: function(error, element){
    error.appendTo( element.next('.help-block') );
  },
  submitHandler: function(form){
    dataString = $('#create-user-form').serialize();
    $.ajax({
      type: "POST",
      url: "insert-user",
      data: dataString,
      dataType: 'json',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
              beforeSend: function(){
         $('#form_submit').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Processing'); 
     $('#form_submit').prop("disabled", true);
      },

   success: function(response)
   {

    if(response.success==true)
    {
      window.location.href=response.linkn;
     
    }
    else{
      $('#form_submit').html('Submit'); 
       $('#form_submit').prop("disabled", false);
      if(response.error_type=='user')
      {
          printErrorMsg(response.message);
      }
      else
      {
        alert(response.message);
        location.reload();
      }
    }
   }

});
  }

});

});
function printErrorMsg (msg) {
  $(".print-error-msg").find("ul").html('');
  $(".print-error-msg").css('display','block');
  $.each( msg, function( key, value ) {
    $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
  });
}

$(document).ready(function() {
  $('#usr_password').keyup(function() {
    $('#result').html(checkStrength($('#usr_password').val()))
  })
  function checkStrength(password) {
    var strength = 0
    if (password.length < 6) {
      $('#result').removeClass()
      $('#result').addClass('short')
      return 'Too short'
    }
    if (password.length > 7) strength += 1
// If password contains both lower and uppercase characters, increase strength value.
if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) strength += 1
// If it has numbers and characters, increase strength value.
if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) strength += 1
// If it has one special character, increase strength value.
if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
// If it has two special characters, increase strength value.
if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
// Calculated strength value, we can return messages
// If value is less than 2
if (strength < 2) {
  $('#result').removeClass()
  $('#result').addClass('weak')
  return 'Weak'
} else if (strength == 2) {
  $('#result').removeClass()
  $('#result').addClass('good')
  return 'Good'
} else {
  $('#result').removeClass()
  $('#result').addClass('strong')
  return 'Strong'
}
}
});





