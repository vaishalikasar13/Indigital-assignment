$(function() 
{
$("#add-slack-url-form").validate({
   ignore: 'input[type="hidden"]',
   rules: {
    bpm_value: {
      required: true,
    },
  },

  errorPlacement: function(error, element){
    error.appendTo( element.next('.help-block') );
  },
  submitHandler: function(form){
    dataString = $('#add-slack-url-form').serialize();
    $.ajax({
      type: "POST",
      url: "update-slack-url",
      data: dataString,
      dataType: 'json',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
      beforeSend: function(){
       $('#form_submit').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Processing'); 
       $('#form_submit').attr('disabled','disabled');
     },

     success: function(response)
     {

      if(response.success==true)
      {
        window.location.href=response.linkn;

      }
      else{
       printErrorMsg(response.message);
     }
   }

 });
  }

});

});
function printErrorMsg (msg) {
  $(".print-error-msg").find("ul").html('');
  $(".print-error-msg").css('display','block');
  $.each( msg, function( key, value ) {
    $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
  });
}



