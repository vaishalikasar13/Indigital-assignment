$(function() 
{
 $("#slack-testing-form").validate({

    errorPlacement: function(error, element){
      error.appendTo( element.next('.help-block') );
    },
    submitHandler: function(form){
      dataString = $('#slack-testing-form').serialize();
      $.ajax({
        type: "POST",
        url: "slack-testing",
        data: dataString,
        dataType: 'json',
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        cache: false,
        beforeSend: function(){
         $('#form_submit').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Processing'); 
         $('#form_submit').attr('disabled','disabled');
       },

       success: function(response)
       {
        if(response.success==true)
        {
          alert(response.message);
          location.reload();
        }
        else{
         alert(response.message);
         location.reload();
       }
     }

   });
    }

  });

});



