<!DOCTYPE html>
<html>
<head>
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<title>Slack Messanger  Testing</title>
<body>
	
	
	<form  style="border:1px solid #ccc" id="slack-testing-form">
		<div class="container">
		<div class="row">
		<div class="alert alert-danger print-error-msg" style="display:none">
        <ul></ul>
    	</div>
			<h2 align="center">Slack Messanger  Testing</h2>
		  <div class="form-group col-md-6">
				<label><b>Name</b> <span style="color:red">*</span></label>
			<input type="text" placeholder="Enter Name" name="slk_usr_name" id="slk_usr_name" required>
			 <span class="help-block"></span>
			</div>
			  <div class="form-group col-md-6">
				<label><b>Mobile</b> <span style="color:red">*</span></label>
			<input type="text" placeholder="Enter Mobile No." name="slk_usr_mobile" id="slk_usr_mobile" required>
			 <span class="help-block"></span>
			</div>
			<div class="form-group col-md-6">
			<button type="submit"  id="form_submit" class="signupbtn">Submit</button>
			 </div>
			
		</div>
		</div>
	</form>
	<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/jquery.validate.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/slack-testing.js')); ?>"></script>
</body>
</html>
