<!DOCTYPE html>
<html lang="en">
<head>
	<title>ACTIVE USERS</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

	<div class="container">
		
Hello <?php echo e(Session::get('user')[0] ['ass_usr_name']); ?>


		<h2>ACTIVE USERS</h2>

		<table class="table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Mobile</th>
					<th>Company Name</th>
					<th>Designation</th>
					<th>Company Size</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($retrive->usr_name); ?></td>
					<td><?php echo e($retrive->usr_email); ?></td>
					<td><?php echo e($retrive->usr_mobile); ?></td>
					<td><?php echo e($retrive->usr_company_name); ?></td>
					<td><?php echo e($retrive->usr_designation); ?></td>
					<td><?php echo e($retrive->usr_company_size); ?></td>
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</tbody>
		</table>
		<a href="<?php echo e(url('create-user')); ?>" class="btn btn-info">
      <span class="glyphicon glyphicon-plus"></span> Register
    </a>
	</div>

</body>
</html>
