<!DOCTYPE html>
<html>
<head>
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/style.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<title>Create User</title>
<body>
	
	
	<form  style="border:1px solid #ccc" id="create-user-form">
		
	
		<div class="container">
		<div class="row">
			<div class="alert alert-danger print-error-msg" style="display:none">
        <ul></ul>
    </div>

     
			<h2 align="center">Registration Form</h2>
		  <div class="form-group col-md-6">
				<label><b>Name</b> <span style="color:red">*</span></label>
			<input type="text" placeholder="Enter Name" name="usr_name" id="usr_name">

			 <span class="help-block"></span>
			</div>

				<div class="form-group col-md-6">
			<label><b>Email</b> <span style="color:red">*</span></label>
			<input type="email" placeholder="Enter Email" name="usr_email" id="usr_email">
			 <span class="help-block"></span>
			 </div>
			 <div class="form-group col-md-6">
			<label><b>Mobile</b> <span style="color:red">*</span></label>
			<input type="text" placeholder="Enter Mobile" name="usr_mobile" id="usr_mobile" maxlength="10">
			 <span class="help-block"></span>
			 </div>
			   <div class="form-group col-md-6">
			 <label><b>Company Name</b> <span style="color:red">*</span></label>
			<input type="text" placeholder="Enter Company Name" name="usr_company_name" id="usr_company_name">
			 <span class="help-block"></span>
			  </div>
			  <div class="form-group col-md-6">
			<label><b>Password</b> <span style="color:red">*</span></label> <span id="result"></span>
			<input type="password" placeholder="At least 6 characters " name="usr_password" id="usr_password">
			<span class="help-block"></span>
			
			 
			  </div>
			    <div class="form-group col-md-6">
			<label><b>Repeat Password</b> <span style="color:red">*</span></label>
			<input type="password" placeholder="Repeat Password" name="usr_password_repeat" id="usr_password_repeat">
			 <span class="help-block"></span>
			 </div>
			  <div class="form-group col-md-6">
			<label><b>Designation</b></label>
			<input type="text" placeholder="Enter Designation" name="usr_designation" id="usr_designation">
			 </div>
			  <div class="form-group col-md-6">
			<label><b>Company Size</b></label>
			<input type="text" placeholder="Enter Comapany Size" name="usr_company_size" id="usr_company_size">
			 </div>
			   <div class="form-group col-md-6">
			   	<label><b>Captcha</b></label>
			<?php echo Igoshev\Captcha\Facades\Captcha::getView() ?>
			 </div>
			  <div class="form-group col-md-6">
			  	<label><b>Captcha <span style="color:red">*</span></b></label>
		<input type="text" id="captcha" name="captcha" placeholder="Enter code from the image">
			<span class="help-block"></span>
			 </div>
			<div class="clearfix">
				<button type="submit" class="signupbtn" id="form_submit">Sign Up</button>
				<button type="button" class="cancelbtn" onclick="history.go(-1)">Cancel</button>

			</div>
		</div>
		</div>
	</form>
	<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/jquery.validate.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/create-user.js')); ?>"></script>
</body>
</html>
