<?php

namespace App\Http\Controllers;
use Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Input;
use Log;
use Illuminate\Support\Facades\Request;
use Igoshev\Captcha\Facades\Captcha;
use Session;
use App\User;
use App\Notifications\errorNotification;
use DB;
class UserController extends Controller
{
   protected $table = 'users';
 
    public function userListView()
  {
  $user_data =  DB::table('users')->where('usr_status',env('ACTIVE_STATUS'))->orderBy('created_at', 'dsc')->get();
  return view('user-list', compact('user_data'));
  }

 public function createUser(Request $request)
 {

  $input = Input::only(
    'usr_name',
    'usr_email',
    'usr_mobile',
    'usr_password',
    'usr_password_repeat',
    'usr_company_name',
    'captcha'
    );
  $messsages = array(
    'usr_name.required'=>"Enter your name.",
    'usr_email.required'=>"Enter your email.",
    'usr_email.email'=>"Enter valid email.",
    'usr_email.unique'=>" ".Input::post('usr_email')." has already been used. Please use another Email address.",
    'usr_mobile.required'=>"Enter your mobile No.",
    'usr_mobile.min'=>"Enter valid Mobile No.",
    'usr_mobile.max'=>"Enter valid Mobile No.",
    'usr_mobile.unique'=>" ".Input::post('usr_mobile')." has already been used. Please use another Mobile No.",
    'usr_password.required'=>"Enter your password.",
    'usr_password.min'=>"Password must be 6 digit long",
    'usr_password_repeat.required'=>"Enter repeate password.",
    'usr_password_repeat.confirmed'=>"Enter the same value again.",
    'usr_company_name.required'=>"Enter company name."
    );

  $rules = array(
      'usr_name' => 'required',
      'usr_mobile' => ['required','min:10','max:10',Rule::unique('users', 'usr_mobile')->where(function($query) {$query->where('usr_mobile', $_POST['usr_mobile']);})],
      'usr_email' =>['required', 'email', Rule::unique('users', 'usr_email')->where(function($query) {$query->where('usr_email', $_POST['usr_email']);})],
      'usr_password' => 'required|string|min:6',
      'usr_password_repeat' => 'required',
      'usr_company_name' => 'required',
      'captcha' => 'required|captcha'
      );
  $validator = Validator::make($input , $rules,$messsages);
  if ($validator->passes())
  {

     try 
     {
      $user = new User;

     $user->usr_name = trim(Input::post('usr_name'));
     $user->usr_email = trim(Input::post('usr_email'));
     $user->usr_mobile = trim(Input::post('usr_mobile'));
     $user->usr_password =  bcrypt(trim(Input::post('usr_password')));
     $user->usr_company_name = trim(Input::post('usr_company_name'));
     $user->usr_designation = trim(Input::post('usr_designation'));
     $user->usr_company_size = trim(Input::post('usr_company_size'));
     $user->usr_status =   env('ACTIVE_STATUS');
     $user->save();
     $userdata = 
    array
    (
    'ass_usr_id' => $user->id,
    'ass_usr_name'  => Input::get('usr_name'),
    );
    Session::push('user', $userdata);
    echo json_encode(array("success"=>true,"message"=>"Added new records.","linkn"=>'users'));
    }
    catch (\Exception $e)
    {
    $admin=User::find(1);
    $admin->notify(new errorNotification($e->getMessage()));
    echo json_encode(array("success"=>false,"message"=>"Some Error Occured Try Again","error_type"=>'sysytem'));
    }
 
  }
  else
  {
   echo json_encode(array("success"=>false,"message"=>$validator->errors()->all(),"error_type"=>'user'));   
  }

}

 public function validateEmail()
{
  $getUserByEmail = DB::table('users')->where('usr_email', Input::post('usr_email'));
  if($getUserByEmail->count() == 0)
  {
    return 'true';
  }
  else
  {
  return 'false';
  }
}
 public function validateMobile()
{
  $getUserByMobile = DB::table('users')->where('usr_mobile', Input::post('usr_mobile'));
  if($getUserByMobile->count() == 0)
  {
    return 'true';
  }
  else
  {
  return 'false';
  }
}
public function updateAdminSlackUrl()
{
  $input = Input::only('bpm_value');
  $rules = array('bpm_value' => 'required');
  $messsages = array('bpm_value.required'=>"Enter Slack Webhook URL.");
  $validator = Validator::make($input  , $rules, $messsages );
  if ($validator->passes())
   {
    DB::table('bsn_prm')->where('bpm_name',env('SLACK_URL_BSN_NAME'))->update( array('bpm_value'=>Input::post('bpm_value')) );
    echo json_encode(array("success"=>true,"message"=>"Added new records.","linkn"=>'slack-testing'));
   }
  else
  {
   echo json_encode(array("success"=>false,"message"=>$validator->errors()->all()));     
  }
}
public function slackTesting()
{
  try
   {
    DB::table('slack')->insert(
    array('slk_usr_name' => Input::post('slk_usr_name'),
          'slk_usr_mobile1' => Input::post('slk_usr_mobile')));
    echo json_encode(array("success"=>true,"message"=>"Data has been inserted successfully."));
    }
  catch (\Exception $e)
   {
  
   $admin = new User;
   $admin->notify(new errorNotification($e->getMessage()));
   echo json_encode(array("success"=>false,"message"=>"Check your slack messanger.You have received an notification about error."));
   }
}
}

