<?php

namespace App\Models;
use App\User;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use DB;

use App\Notifications\PaymentReceived;

class User extends Model
{
      protected $table = 'users1';
   public static  function store()
   {
        // Validate the request...
    try {
 $user = new User;

     $user->usr_name = Input::get('usr_name');
     $user->usr_email = Input::get('usr_email');
     $user->usr_mobile1 = Input::get('usr_mobile');
     $user->usr_password =  bcrypt(Input::post('usr_password'));
     $user->usr_company_name = Input::get('usr_company_name');
     $user->usr_designation = Input::get('usr_designation');
     $user->usr_company_size = Input::get('usr_company_size');
      $user->usr_status =   env('ACTIVE_STATUS');
     $user->save();
     return  $user->id;
}
catch (\Exception $e)
 {

    // echo $e->getMessage();

    $admin=App\User::find(4);
   $admin->notify(new PaymentReceived());
}
   
     

 }
 public static function getUserData()
{
    return DB::table('users')->where('usr_status',env('ACTIVE_STATUS'))->orderBy('created_at', 'dsc')->get();
   
}
public static function getUserDataById()
{
    return DB::table('users')->where('usr_id',1)->orderBy('created_at', 'dsc')->get();
   
}
}
