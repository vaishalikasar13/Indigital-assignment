<!DOCTYPE html>
<html lang="en">
<head>
	<title>ACTIVE USERS</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

	<div class="container">
		
Hello {{ Session::get('user')[0] ['ass_usr_name']}}

		<h2>ACTIVE USERS</h2>

		<table class="table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Mobile</th>
					<th>Company Name</th>
					<th>Designation</th>
					<th>Company Size</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($user_data as $retrive)
				<tr>
					<td>{{ $retrive->usr_name }}</td>
					<td>{{ $retrive->usr_email }}</td>
					<td>{{ $retrive->usr_mobile }}</td>
					<td>{{ $retrive->usr_company_name }}</td>
					<td>{{ $retrive->usr_designation }}</td>
					<td>{{ $retrive->usr_company_size }}</td>
				</tr>

				@endforeach



			</tbody>
		</table>
		<a href="{{ url('create-user') }}" class="btn btn-info">
      <span class="glyphicon glyphicon-plus"></span> Register
    </a>
	</div>

</body>
</html>
