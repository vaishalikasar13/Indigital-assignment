<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

<div class="container">
	<h2>INDIGITAL TECHNOLOGIES ASSIGNMENT FOR Sr. SOFTWARE ENGINEER</h2>
  
   <a  href="{{url('users')}}" class="btn btn-info">
     USER REGISTRATION
    </a>

   <a  href="{{url('slack')}}" class="btn btn-info">
     SLACK INTEGRATION
    </a>
 </div>

</body>
</html>
