<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Models\User;
use App\Notifications\PaymentReceived;


Route::get('/', function () 
{
    return view('task');
});

Route::get('slack', function () 
{
    return view('add-slack-url');
});



Route::get('users', 'UserController@userListView');

Route::get('create-user', function () 
{
    return view('create-user');
});




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::post('insert-user', 'UserController@createUser');
Route::post('validate-email', 'UserController@validateEmail');
Route::post('validate-mobile', 'UserController@validateMobile');
Route::post('update-slack-url', 'UserController@updateAdminSlackUrl');
Route::post('slack-testing', 'UserController@slackTesting');

Route::get('slack-testing', function () 
{
    return view('slack-testing');
});
